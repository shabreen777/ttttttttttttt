# Testing Using Assertion

Write JUNIT test class named CustomerTest to test the attributes given in the Customer class.

1. Test whether the Aadhar card no is valid or not by using assertTrue() and assertFalse() methods. The Aadhaar card number should contain 16 digits. It should not start with 0 or 1.
2. Test whether the firstname and lastname are not equal by using assertNotEquals() method
3. Test whether the Email id is not null by using assertNotNull() method
 
You need to write only JUNIT code.