import React from 'react';
import {CalculateScore} from './Components/CalculateScore';

function App()
{
  return(
    <div>
      <CalculateScore Name={"Shabreen Fathima"}
      School={"OCPM Matriculatoin"}
      total={488}
      goal={5}
      />
    </div>
  )
}
export default App;