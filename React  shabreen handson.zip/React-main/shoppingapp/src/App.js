import React from 'react';
import OnlineShopping from './onlineshopping/OnlineShopping';
import './App.css';
class App extends React.Component {
  render() {
    return (
      <div className='App'>
        <OnlineShopping />
      </div>
    )
  }

}
export default App;