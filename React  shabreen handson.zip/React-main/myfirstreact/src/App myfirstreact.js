import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>welcome the first session of npm react</h1>
    </div>
  );
}

export default App;
