package com.AutoIdentificationSystem.Controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.AutoIdentificationSystem.model.Customer;
import com.AutoIdentificationSystem.service.CustomerService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class EmployeeController {

	/*
	 * /bankEmp G viewCustomer G less90 G alert90 G /90-180 G alert90-180 G 180-365
	 * G blockCard G great365 G
	 */

	@Autowired
	private CustomerService customerService;

	// all customers
	@GetMapping("/employeeHome")
	public String employeeHome(ModelMap model, HttpServletRequest request, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			List<Customer> allDef = customerService.getAllDefaulters();
			model.addAttribute("list", allDef);
			return "employeeHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	// view customer
	@GetMapping("/viewCustomer")
	public String view(@RequestParam int id, @ModelAttribute("customer") Customer c, Model model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			Customer s = customerService.getSingleCust(id);
			model.addAttribute("details", s);
			return "viewCustomer";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	@GetMapping("/less90")
	public String d1(@ModelAttribute("cust") Customer c, Model model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			List<Customer> dueList = customerService.lessThan3();
			customerService.deactivateCard();
			model.addAttribute("dueList", dueList);
			model.addAttribute("due", 1);
			return "duePage";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	@GetMapping("/90-180")
	public String d2(Model model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			List<Customer> dueList = customerService.great3Less6();
			customerService.deactivateCard();
			model.addAttribute("dueList", dueList);
			model.addAttribute("due", 2);
			return "duePage";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	@GetMapping("/180-365")
	public String d3(Model model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			List<Customer> dueList = customerService.great6Less12();
			customerService.deactivateCard();
			model.addAttribute("dueList", dueList);
			model.addAttribute("due", 3);
			return "duePage";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	// auto cancel card to be implemented
	@GetMapping("/great365")
	public String d4(Model model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			List<Customer> dueList = customerService.great12();
			customerService.deactivateCard();
			model.addAttribute("dueList", dueList);
			model.addAttribute("due", 4);
			return "duePage";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	// block card
	@GetMapping("/blockCard")
	public String blockCard(@RequestParam int id, @ModelAttribute("cust") Customer c, Model model,
			HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			customerService.blockCard(id);
			model.addAttribute("email", c.getEmail());
			Date plus = null;
			model.addAttribute("date", customerService.datePlus(plus));
			return "blockCardSuccess";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	// block card
	@GetMapping("/reActivateCard")
	public String reActivateCardGet(@RequestParam int id, @ModelAttribute("cust") Customer cust, Model model,
			HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			Customer c = customerService.getSingleCust(id);
			model.addAttribute("cust", new Customer());
			model.addAttribute("customer", c);
			return "reActivateCard";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

	@PostMapping("/reActivateCard")
	public String reActivateCardPost(@RequestParam int id, @ModelAttribute("cust") Customer cust, Model model,
			HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			log.info("Bhaiyu: " + cust);
			customerService.reActivateCard(id, cust.getPastDue(), cust.getRepaymentDate(),
					cust.getReactivationReason());
			Customer c = customerService.getSingleCust(id);
			model.addAttribute("reactivate", true);
			model.addAttribute("email", c.getEmail());
			Date plus = null;
			model.addAttribute("date", customerService.datePlus(plus));
			return "alert";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else {
			return "redirect:/employeeLogin";
		}
	}

}
