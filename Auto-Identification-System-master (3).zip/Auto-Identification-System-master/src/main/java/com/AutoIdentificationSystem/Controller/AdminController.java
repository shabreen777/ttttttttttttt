package com.AutoIdentificationSystem.Controller;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.AutoIdentificationSystem.model.Customer;
import com.AutoIdentificationSystem.service.CustomerService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AdminController {

	@Autowired
	private CustomerService customerService;


	// auto defaulter customer list in admin GET
	@GetMapping("/adminHome")
	public String adminHome(ModelMap model, HttpServletRequest request, HttpSession session) {
		if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("admin") ) {
			List<Customer> auto = customerService.getAutoDefaults();
			model.addAttribute("auto", auto);
			return "adminHome";
		} else if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			return "redirect:/adminLogin";
		}
	}

	
	// manual defaulter customer list in admin GET
	@GetMapping("/manualDefaulters")
	public String adminManualDefaulter(ModelMap model, HttpServletRequest request, HttpSession session) {
		if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("admin") ) {
			List<Customer> manual = customerService.getManualDefaults();
			model.addAttribute("manual", manual);
			return "manualDefaulter";
		} else if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			return "redirect:/adminLogin";
		}
	}
		
		
	// generate report in admin GET
	@GetMapping("/generateReport")
	public String adminGene(ModelMap model, HttpServletRequest request, HttpSession session) {
		if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("admin") ) {
			HashMap<String, Integer> data = customerService.generateReport();
			model.addAttribute("data", data);
			return "generateReport";
		} else if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			return "redirect:/adminLogin";
		}
	}
		

	//EDIT

	@GetMapping("/editCustomer")
	public String editCustomer(@RequestParam int id, @ModelAttribute("cust") Customer cust, Model model, HttpSession session) {
		if(session.getAttribute("name")!=null) {
			Customer c = customerService.getSingleCust(id);
			model.addAttribute("cust", new Customer());
			model.addAttribute("customer", c);
			return "editCustomer";
		} else {
			return "redirect:/adminLogin";
		}
	}

	@PostMapping("/editCustomer")
	public String saveEdited(@RequestParam int id, @ModelAttribute("cust") Customer c, ModelMap model, HttpSession session) {
		if(session.getAttribute("name")!=null ) {
			customerService.updateSingleCust(c);
			log.info("CUST 100: "+ c+ " / "+id);
			model.put("customer", c);
			return "editSuccess";
		} else if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			return "redirect:/adminLogin";
		}
	}

	@GetMapping("/dueList")
	public String dueList(@ModelAttribute("cust") Customer cust, Model model, HttpSession session) {
		if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("admin") ) {
			List<Customer> due = customerService.dueGT180();
			model.addAttribute("dueList", due);
			return "duePage";
		} else if(session.getAttribute("name")!=null && String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			return "redirect:/adminLogin";
		}
	}

	@GetMapping("/sendAlert")
	public String sendAlert(@RequestParam int id, @ModelAttribute("cust") Customer cust, Model model, HttpServletRequest request, HttpSession session) {
		if(session.getAttribute("name")!=null ) {
			Customer c = customerService.getSingleCust(id);
			model.addAttribute("email", c.getEmail());
			Date plus = null;
			model.addAttribute("date", customerService.datePlus(plus));
			return "alert";
		} else {
			return "redirect:/adminLogin";
		}
	}

}
