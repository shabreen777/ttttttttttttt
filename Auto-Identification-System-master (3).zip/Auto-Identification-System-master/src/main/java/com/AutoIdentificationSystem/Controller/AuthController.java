package com.AutoIdentificationSystem.Controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.AutoIdentificationSystem.Validator.CustomValidator;
import com.AutoIdentificationSystem.model.Employee;
import com.AutoIdentificationSystem.model.Admin;
import com.AutoIdentificationSystem.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AuthController {
	@Autowired
	private UserService userService;

	@Autowired
	private CustomValidator validator;

	/*
	 * / /adminLogin --- get/ post /signup --- get /signUpSuccess --- post
	 * /employeeLogin --- get /logout --- get
	 */

//	landing page
	@GetMapping("/")
	public String rolePage(HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			return "roleSelect";
		}
	}

//	ADMIN

	// admin login
	@GetMapping("/adminLogin")
	public String adminLoginGet(ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			model.addAttribute("users", new Admin());
			return "adminLogin";
		}
	}

	// admin login post
	@PostMapping("/adminLogin")
	public String adminLoginPost(@ModelAttribute("users") Admin user, ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			if (userService.validateAdmin(user.getUsername(), user.getPassword())) {
				session.setAttribute("name", user.getUsername());
				session.setAttribute("role", "admin");
				return "radminHome";
			} else {
				model.addAttribute("error", "Invalid UserId / Password");
				return "adminLogin";
			}
		}
	}

//	EMPLOYEE

// employee login page
	@GetMapping("employeeLogin")
	public String employeeLoginGet(ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			model.addAttribute("users", new Admin());
			return "employeeLogin";
		}
	}

	// employee login post
	@PostMapping("/employeeLogin")
	public String employeeLoginPost(@ModelAttribute("users") @Valid Admin user, ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			String username = user.getUsername();
			String password = user.getPassword();
			if (userService.validateBankEmployee(username, password)) {
				session.setAttribute("name", username);
				session.setAttribute("role", "employee");
				return "redirect:/employeeHome";
			} else {
				model.addAttribute("error", "Invalid Username/ Password");
				return "employeeLogin";
			}
		}
	}

	// forgot password
	@GetMapping("/forgotPassword")
	public String forgotPasswordGet(@ModelAttribute("emp") @Valid Employee emp, ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			return "forgotPassword";
		}
	}

	// forgot password POST
	@PostMapping("/forgotPassword")
	public String forgotPasswordPost(@ModelAttribute("emp") @Valid Employee emp, ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			Employee employee = userService.getEmployee(emp.getUsername());
			if (employee != null) {
				return "redirect:/forgotPassword2?username=" + employee.getUsername();
			} else {
				model.addAttribute("error", "No Employee with username: " + emp.getUsername() + " exist.");
				return "forgotPassword";
			}
		}
	}

	// forgot password 2
	@GetMapping("/forgotPassword2")
	public String forgotPasswordGet2(@RequestParam String username, @ModelAttribute("emp") @Valid Employee emp,
			ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			Employee employee = userService.getEmployee(username);
			model.addAttribute("question1", employee.getQuestion1());
			model.addAttribute("question2", employee.getQuestion2());
			model.addAttribute("question3", employee.getQuestion3());
			return "forgotPassword2";
		}
	}

	// forgot password 2 POST
	@PostMapping("/forgotPassword2")
	public String forgotPasswordPost2(@ModelAttribute("emp") @Valid Employee emp, ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			Employee employee = userService.getEmployee(emp.getUsername());
			if (emp.getAnswer1() == employee.getAnswer1() && emp.getAnswer2() == employee.getAnswer2()
					&& emp.getAnswer3() == employee.getAnswer3()
					&& emp.getContactNumber() == employee.getContactNumber()
					&& emp.getDateOfBirth() == employee.getDateOfBirth()
					&& emp.getUsername() == employee.getUsername()) {
				return "redirect:/resetPassword?username=" + emp.getUsername();
			}
			model.addAttribute("error",
					"Sorry wrong details for username: " + emp.getUsername() + ". Can't reset the password.");
			return "forgotPassword";
		}
	}

	// RESET password 2
	@GetMapping("/resetPassword")
	public String resetPasswordGet(@RequestParam String username, @ModelAttribute("emp") @Valid Employee emp,
			ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			model.addAttribute("username", username);
			return "resetPassword";
		}
	}

	// RESET password POST
	@PostMapping("/resetPassword")
	public String resetPasswordPost(@RequestParam String username, @ModelAttribute("emp") @Valid Employee emp,
			BindingResult b, ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			validator.validatePassword(emp, b);
			if (b.hasErrors()) {
				model.addAttribute("username", username);
				return "resetPassword";
			}
			Employee employee = userService.getEmployee(username);
			if (employee == null) {
				model.addAttribute("error", "Sorry wrong username: ");
				return "redirect:/employeeLogin";
			} else if (emp.getPassword().equals(emp.getPassword2())) {
				log.info("*-*-*-*-*-*-*-*-* 69: " + username + " - " + emp);
				userService.changePassword(username, emp.getPassword());
				return "redirect:/employeeLogin";
			} else {
				model.addAttribute("error", "Sorry passwords do not match.");
				model.addAttribute("username", username);
				return "resetPassword?username=" + username;
			}
		}
	}

	// employee signup GET
	@GetMapping("/employeeSignup")
	public String employeeSignupGet(ModelMap model, HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "redirect:/adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			model.addAttribute("register", new Employee());
			return "employeeSignup";
		}
	}

	// employee signup POST
	@PostMapping("/employeeSignup")
	public String employeeSignupPost(@ModelAttribute("register") Employee reg, BindingResult b, ModelMap model,
			HttpSession session) {
		if (session.getAttribute("name") != null && String.valueOf(session.getAttribute("role")).equals("admin")) {
			return "adminHome";
		} else if (session.getAttribute("name") != null
				&& String.valueOf(session.getAttribute("role")).equals("employee")) {
			return "redirect:/employeeHome";
		} else {
			validator.validate(reg, b);
			if (b.hasErrors()) {
				return "employeeSignup";
			}
			String user = reg.getUsername();
			model.addAttribute("username", user);
			userService.addEmployee(reg);
			return "BankEmpSuccess";
		}
	}

//	LOGOUT

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("name");
		session.removeAttribute("role");
		log.error(session.getAttribute("name") + " : " + session.getAttribute("role"));
		session.invalidate();
		return "redirect:/";
	}
}
