package com.AutoIdentificationSystem.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Component
@Entity
@Table(name = "employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String firstName;
	@Column
	private String lastName;
	@Column
	private Date dateOfBirth;
	@Column
	private String gender;
	@Column
	private long contactNumber;
	@Column
	private String city;
	@Column
	private String state;
	@Column(unique=true)
	private String username;
	@Column
	private String password;
	@Column
	private String password2;
	@Column
	private String question1;
	@Column
	private String question2;
	@Column
	private String question3;
	@Column
	private String answer1;
	@Column
	private String answer2;
	@Column
	private String answer3;
}