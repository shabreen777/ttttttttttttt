package com.AutoIdentificationSystem.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "customer")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String custName;
	@Column
	private long custAccNum;
	@Column
	private long debitNum;
	@Column
	private long creditNum;
	@Column
	private long creditLimit;
	@Column
	private boolean creditStatus;
	@Column
	private int borrowerRate;
	@Column
	@Max(7)
	private int accuralStatus;
	@Column
	private String email;
	@Column
	private long amountUsed;
	@Column
	private Date paymentUsedDate;
	@Column
	private Date repaymentDate;
	@Column
	private int pastDue;
	@Column
	private String defaultStatus;
	@Column
	private String comments;
	@Column
	private String reactivationReason;
	@Column
	private String cardStatus;

}
