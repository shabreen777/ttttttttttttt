package com.AutoIdentificationSystem.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.AutoIdentificationSystem.model.Customer;

@Component
public interface CustomerDAO {
	public List<Customer> getAutoDefaults();

	public List<Customer> getManualDefaults();

	public List<Customer> getAllDefaulters();

	public List<Customer> dueGT6M();

	public void addCustomer(Customer c);

	public List<Customer> lessThan3();

	public List<Customer> great3Less6();

	public List<Customer> great6Less12();

	public List<Customer> great12();

	public Customer getSingleCust(int id);

	public Customer updateSingleCust(Customer cust);
	
	public void blockCard(int id);
	
	public void reActivateCard(int id, int pastDue, Date repaymentDate, String reactivationReason);
	
	public void deactivateCard();
}
