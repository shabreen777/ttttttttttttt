package com.AutoIdentificationSystem.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.AutoIdentificationSystem.model.Employee;
import com.AutoIdentificationSystem.model.Admin;

@Component
public interface UserDAO {
	public void addEmployee(Employee emp);

	public Admin getAdmin(String username, String password);

	public Employee getBankEmployee(String username, String password);

	public List<Employee> getAllEmployees();
	
	public Employee getEmployee(String username);

	public void changePassword(String username, String password);
}
