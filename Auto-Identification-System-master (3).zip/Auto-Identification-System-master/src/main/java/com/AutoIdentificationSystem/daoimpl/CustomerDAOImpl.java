package com.AutoIdentificationSystem.daoimpl;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Component;

import com.AutoIdentificationSystem.dao.CustomerDAO;
import com.AutoIdentificationSystem.model.Customer;
import com.AutoIdentificationSystem.repository.CustomerRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	CustomerRepository customerRepository;

//FETCH

//	get all defaults
	@Override
	public List<Customer> getAllDefaulters() {
		List<Customer> list = customerRepository.getAllDefaulters();
		return list;
	}

//	 Get auto defaults
	@Override
	public List<Customer> getAutoDefaults() {
		List<Customer> list = customerRepository.getAutoDefaults();
		return list;
	}

//	 Get Manual defaults
	@Override
	public List<Customer> getManualDefaults() {
		List<Customer> list = customerRepository.getManualDefaults();
		return list;
	}
	
	//Generate report
	public HashMap<String, Integer> generateReport() {
		HashMap<String, Integer> data = new HashMap<String, Integer>();
		data.put("defaulters", customerRepository.generateReportAll());
	    data.put("autoDefaulters", customerRepository.generateReportAuto());
	    data.put("manualDefaulters", customerRepository.generateReportManual());
	    //figure this field out
	    data.put("reactivationRequests", 5);
		return data;
	}
	
	

//	get customer details by name
	@Override
	public Customer getSingleCust(int id) {
		try {
			Customer cust = customerRepository.getSingleCust(id);
			return cust;
		} catch (EmptyResultDataAccessException e) {
			log.error("Exception Caught!!");
			return null;
		}
	}

//	add customer
	@Override
	public void addCustomer(Customer customer) {
		customerRepository.addCustomer(customer.getBorrowerRate(), customer.getAccuralStatus(), customer.getPastDue());
	}

//UPDATE

//	update customerdetails
	@Override
	public Customer updateSingleCust(Customer cust) {
		customerRepository.updateSingleCust(cust.getBorrowerRate(), cust.getAccuralStatus(), cust.getPastDue(), cust.getId(),
				cust.getDefaultStatus(), cust.getComments(), cust.getCustName(), cust.getCustAccNum(), cust.getDebitNum(), cust.getCreditNum(),
				cust.getCreditLimit(), cust.getEmail(), cust.getAmountUsed(), cust.getPaymentUsedDate(), cust.getRepaymentDate(), cust.getCardStatus(), cust.isCreditStatus());
		return cust;
	}
	
	//block card
	@Override
	public void blockCard(int id) {
		customerRepository.blockCard(id);
	}
	
	@Override
	public void reActivateCard(int id, int pastDue, Date repaymentDate, String reactivationReason) {
		customerRepository.reActivateCard(id, pastDue, repaymentDate, reactivationReason);
	}
	
//	pastdue >=180
	@Override
	public List<Customer> dueGT6M() {
		List<Customer> list = customerRepository.dueGT6M();
		return list;
	}

//	pastdue <=90
	@Override
	public List<Customer> lessThan3() {
		List<Customer> list = customerRepository.lessThan3();
		return list;
	}

//	pastdue >90
	@Override
	public List<Customer> great3Less6() {
		List<Customer> list = customerRepository.great3Less6();
		return list;
	}

//	pastdue >180 && pastdue<=365
	@Override
	public List<Customer> great6Less12() {
		List<Customer> list = customerRepository.great6Less12();
		return list;
	}

//	pastdue > 365
	@Override
	public List<Customer> great12() {
		List<Customer> list = customerRepository.great12();
		return list;
	}
	
	@Override
	public void deactivateCard() {
		customerRepository.deactivateCard();
	}

}
