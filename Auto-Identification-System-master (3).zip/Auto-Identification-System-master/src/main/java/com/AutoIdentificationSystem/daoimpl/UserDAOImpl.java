package com.AutoIdentificationSystem.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Component;

import com.AutoIdentificationSystem.dao.UserDAO;
import com.AutoIdentificationSystem.model.Employee;
import com.AutoIdentificationSystem.repository.AdminRepository;
import com.AutoIdentificationSystem.repository.EmployeeRepository;

import lombok.extern.slf4j.Slf4j;

import com.AutoIdentificationSystem.model.Admin;

@Slf4j
@Component
public class UserDAOImpl implements UserDAO {

	@Autowired
	AdminRepository adminRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public Admin getAdmin(String username, String password) {
		try {
			Admin user = adminRepository.getAdmin(username, password);
			return user;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public void addEmployee(Employee emp) {
		employeeRepository.addEmployee(emp.getFirstName(), emp.getLastName(), emp.getDateOfBirth(), emp.getGender(),
				emp.getContactNumber(), emp.getCity(), emp.getState(), emp.getUsername(), emp.getPassword(),
				emp.getQuestion1(),emp.getAnswer1(),emp.getQuestion2(),emp.getAnswer2(),emp.getQuestion3(),
				emp.getAnswer3());
	}

	@Override
	public Employee getBankEmployee(String username, String password) {
		try {
			Employee user = employeeRepository.getBankEmployee(username, password);
			return user;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	@Override
	public Employee getEmployee(String username) {
		return employeeRepository.getEmployee(username);
	}

	@Override
	public void changePassword(String username, String password) {
		employeeRepository.changePassword(username, password);
		log.info(username +" --   NIGGA  -- "+password);
	}
	
	@Override
	public List<Employee> getAllEmployees() {
		try {
			List<Employee> employeeList = employeeRepository.getAllEmployees();
			return employeeList;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

}
