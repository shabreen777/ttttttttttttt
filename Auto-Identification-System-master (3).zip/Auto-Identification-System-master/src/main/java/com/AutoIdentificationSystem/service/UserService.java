package com.AutoIdentificationSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AutoIdentificationSystem.daoimpl.UserDAOImpl;
import com.AutoIdentificationSystem.model.Employee;
import com.AutoIdentificationSystem.model.Admin;

@Service
public class UserService {

	@Autowired
	UserDAOImpl userImpl;

	public boolean validateAdmin(String username, String password) {
		Admin user = userImpl.getAdmin(username, password);
		if (user != null) {
			if (user.getUsername().contentEquals(username) && user.getPassword().contentEquals(password))
				return true;

			return false;
		}
		return false;
	}

	public boolean validateBankEmployee(String username, String password) {
		Employee user = userImpl.getBankEmployee(username, password);
		if (user != null) {
			if (user.getUsername().contentEquals(username) && user.getPassword().contentEquals(password))
				return true;

			return false;
		}
		return false;
	}
	
	public Employee getEmployee(String username) {
		return userImpl.getEmployee(username);
	}
	
	public void changePassword(String username, String password) {
		userImpl.changePassword(username, password);
	}

	public void addEmployee(Employee emp) {
		userImpl.addEmployee(emp);
	}

	public List<Employee> getAllEmployees() {
		return userImpl.getAllEmployees();
	}

}
