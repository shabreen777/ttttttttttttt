package com.AutoIdentificationSystem.service;

import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AutoIdentificationSystem.daoimpl.CustomerDAOImpl;
import com.AutoIdentificationSystem.model.Customer;

@Service
public class CustomerService {

	@Autowired
	CustomerDAOImpl customerImpl;

	@Transactional
	public Customer getSingleCust(int id) {
		return customerImpl.getSingleCust(id);
	}

	@Transactional
	public Customer updateSingleCust(Customer c) {
		customerImpl.updateSingleCust(c);
		return c;
	}
	
	@Transactional
	public void blockCard(int id) {
		customerImpl.blockCard(id);
	}
	
	@Transactional
	public void reActivateCard(int id, int pastDue, Date repaymentDate, String reactivationReason) {
		customerImpl.reActivateCard(id, pastDue , repaymentDate, reactivationReason);
	}

	@Transactional
	public List<Customer> dueGT180() {
		return customerImpl.dueGT6M();
	}

	@Transactional
	public List<Customer> lessThan3() {
		return customerImpl.lessThan3();
	}
	
	@Transactional
	public void deactivateCard() {
		customerImpl.deactivateCard();
	}

	@Transactional
	public List<Customer> great3Less6() {
		return customerImpl.great3Less6();
	}

	@Transactional
	public List<Customer> great6Less12() {
		return customerImpl.great6Less12();
	}

	@Transactional
	public List<Customer> great12() {
		return customerImpl.great12();
	}

	@Transactional
	public List<Customer> getAutoDefaults() {
		List<Customer> cust = customerImpl.getAutoDefaults();
		return cust;
	}

	@Transactional
	public List<Customer> getManualDefaults() {
		List<Customer> cust = customerImpl.getManualDefaults();
		return cust;
	}

	@Transactional
	public HashMap<String, Integer> generateReport() {
		HashMap<String, Integer> data = customerImpl.generateReport(); 
		return data;
	}
	
	@Transactional
	public List<Customer> getAllDefaulters() {
		List<Customer> list = customerImpl.getAllDefaulters();
		return list;
	}

	
	//add 7 days to current date for sending fututre reminder
	@Transactional
	public String datePlus(Date plus) {
		LocalDateTime today = LocalDateTime.now();
		LocalDateTime after7Days = today.plusDays(7);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("E dd-MM-yyyy 'at' HH:mm:ss a");
		String formatDateTime = after7Days.format(format);
		return formatDateTime;
	}

	

}