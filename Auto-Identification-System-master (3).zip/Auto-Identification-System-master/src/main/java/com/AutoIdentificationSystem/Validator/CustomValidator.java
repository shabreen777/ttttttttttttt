package com.AutoIdentificationSystem.Validator;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.AutoIdentificationSystem.model.Employee;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomValidator implements Validator {

	@Override
	public boolean supports(Class<?> target) {
		return Employee.class.equals(target);
	}

	@Override
	public void validate(Object target, Errors errors) {

		Employee form = (Employee) target;
		String phoneNo = String.format("%s", form.getContactNumber());
		
		if (!phoneNo.matches("[0-9]{10}")) {
			errors.rejectValue("contactNumber", "", "*Contact Number should be of 10 digits");
		} /*
			 * else if (phoneNo == "") { errors.rejectValue("contactNumber", "",
			 * "*Contact Number should not be blank"); }
			 */

		if (form.getFirstName().length() < 4 || form.getFirstName().length() > 50) {
			errors.rejectValue("firstName", "", "First Name should be in range 4-50");
		} else if (form.getLastName().length() < 4 || form.getLastName().length() > 50) {
			errors.rejectValue("lastName", "", "Last Name should be in range 4-50");
		}
		
		log.info("---------------------"+form.getPassword());
		if (form.getPassword().length() < 8
				|| !(form.getPassword().matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,}$"))) {
			errors.rejectValue("password", "",
					"*Password should contain minimum 8 characters, at least 1 letter, 1 number and one special character.");
		}

		if (form.getCity().isEmpty() || form.getFirstName().isEmpty() || form.getLastName().isEmpty()) {
			errors.rejectValue("gender", "", "Please enter the (*) mandatory fields");
		}

	}
	
	public void validatePassword(Object target, Errors errors) {

		Employee form = (Employee) target;
		log.info("---------------------"+form.getPassword());
		if (form.getPassword().length() < 8
				|| !(form.getPassword().matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,}$"))) {
			errors.rejectValue("password", "",
					"*Password should contain minimum 8 characters, at least 1 letter, 1 number and one special character.");
		}
		
		if (form.getPassword2().length() < 8
				|| !(form.getPassword2().matches("^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,}$"))) {
			errors.rejectValue("password", "",
					"*Confirm Password should contain minimum 8 characters, at least 1 letter, 1 number and one special character.");
		}

	}
}
