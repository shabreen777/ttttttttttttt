package com.AutoIdentificationSystem.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.AutoIdentificationSystem.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	@Query(value = "select * from customer", nativeQuery = true)
	List<Customer> getAllDefaulters();

	@Query(value = "select * from customer where borrower_rate>7 and (accural_status=2 or accural_status=3 or accural_status=4 or accural_status=5)", nativeQuery = true)
	List<Customer> getAutoDefaults();

	@Query(value = "select * from customer where (borrower_rate>4 and borrower_rate<8) or (accural_status=1 or accural_status=6 or accural_status=7) and past_due>=90", nativeQuery = true)
	List<Customer> getManualDefaults();
	
//	generate report start
	@Query(value="select count(id) from customer", nativeQuery = true)
	int generateReportAll();
	
	@Query(value="select count(id) from customer where borrower_rate>7 and (accural_status=2 or accural_status=3 or accural_status=4 or accural_status=5)", nativeQuery = true)
	int generateReportAuto();
	
	@Query(value="select count(id) from customer where (borrower_rate>4 and borrower_rate<8) or (accural_status=1 or accural_status=6 or accural_status=7) and past_due>=90", nativeQuery = true)
	int generateReportManual();
//	generate report end
	
	
	@Query(value = "select * from customer where id=:id", nativeQuery = true)
	Customer getSingleCust(@Param("id") int id);

	@Query(value = "insert into customer (borrower_rate, accural_status, past_due)values(:BorrowerRate,:AccuralStatus,:Id)", nativeQuery = true)
	void addCustomer(@Param("BorrowerRate") int BorrowerRate, @Param("AccuralStatus") int AccuralStatus,
			@Param("Id") int Id);

	@Query(value = "update customer set borrower_rate=:BorrowerRate, accural_status=:AccuralStatus where id=:Id", nativeQuery = true)
	int update(@Param("BorrowerRate") int BorrowerRate, @Param("AccuralStatus") int AccuralStatus, @Param("Id") int Id);

	@Transactional
	@Modifying
	@Query(value = "update customer set borrower_rate=:BorrowerRate, accural_status=:AccuralStatus, past_due=:PastDue, default_status=:DefaultStatus, comments=:Comments,"
			+ "cust_name=:CustName, cust_acc_num=:CustAccNum, debit_num=:DebitNum, credit_num=:CreditNum, credit_limit=:CreditLimit, email=:Email, amount_used=:AmountUsed, "
			+ "payment_used_date=:PaymentUsedDate, repayment_date=:RepaymentDate, card_status=:CardStatus, credit_status=:CreditStatus where id=:Id", nativeQuery = true)
	int updateSingleCust(@Param("BorrowerRate") int BorrowerRate, @Param("AccuralStatus") int AccuralStatus, @Param("PastDue") int PastDue, @Param("Id") int Id, 
			@Param("DefaultStatus") String DefaultStatus, @Param("Comments") String Comments, @Param("CustName") String CustName, @Param("CustAccNum") long CustAccNum, 
			@Param("DebitNum") long DebitNum, @Param("CreditNum") long CreditNum, @Param("CreditLimit") long CreditLimit,@Param("Email")  String Email, 
			@Param("AmountUsed") long AmountUsed, @Param("PaymentUsedDate") Date PaymentUsedDate, @Param("RepaymentDate") Date RepaymentDate, @Param("CardStatus") String CardStatus, 
			@Param("CreditStatus") boolean CreditStatus);

//	---
	
	@Query(value = "select * from customer where past_due<=90 and past_due>0", nativeQuery = true)
	List<Customer> lessThan3();

	@Query(value = "select * from customer where past_due>90 and past_due<=180", nativeQuery = true)
	List<Customer> great3Less6();

	@Query(value = "select * from customer where past_due>=180", nativeQuery = true)
	List<Customer> dueGT6M();

	@Query(value = "select * from customer where past_due>180 and past_due<=365", nativeQuery = true)
	List<Customer> great6Less12();

	@Query(value = "select * from customer where past_due>365", nativeQuery = true)
	List<Customer> great12();
	
	@Transactional
	@Modifying
	@Query(value="update customer set card_status='blocked' where id=:id", nativeQuery = true)
	void blockCard(@Param("id") int id);
	
	@Transactional
	@Modifying
	@Query(value="update customer set card_status='inactive' where past_due>365", nativeQuery = true)
	void deactivateCard();
	
	
	@Transactional
	@Modifying
	@Query(value="update customer set card_status='active', reactivation_reason=:reactivationReason, repayment_date=:repaymentDate, past_due=:pastDue where id=:id", nativeQuery = true)
	void reActivateCard(@Param("id") int id, @Param("pastDue") int pastDue, @Param("repaymentDate") Date repaymentDate, @Param("reactivationReason") String reactivationReason);
	

}