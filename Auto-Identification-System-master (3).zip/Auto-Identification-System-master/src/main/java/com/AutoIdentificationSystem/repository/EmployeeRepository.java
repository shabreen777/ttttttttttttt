package com.AutoIdentificationSystem.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.AutoIdentificationSystem.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Transactional
	@Modifying
	@Query(value = "insert into employee (first_name , last_name , date_of_birth , gender , contact_number ,city , state , username , password,question1,answer1,question2,answer2,question3,answer3) values(:firstname, :lastname, :dateofbirth, :gender , :contactnumber, :city, :state, :username, :password, :question1,:answer1, :question2, :answer2, :question3, :answer3)", nativeQuery = true)
	void addEmployee(@Param("firstname") String firstname, @Param("lastname") String lastname,
			@Param("dateofbirth") Date dateofbirth, @Param("gender") String gender,
			@Param("contactnumber") long contactnumber, @Param("city") String city, @Param("state") String state,
			@Param("username") String username, @Param("password") String password, @Param("question1") String question1, 
			@Param("answer1") String answer1,@Param("question2") String question2,@Param("answer2") String answer2,@Param("question3") String question3,
			@Param("answer3") String answer3);

	@Query(value = "select * from employee where username=:username and password=:password", nativeQuery = true)
	Employee getBankEmployee(@Param("username") String username, @Param("password") String password);

	@Query(value = "select * from employee", nativeQuery = true)
	List<Employee> getAllEmployees();
	
	@Query(value = "select * from employee where username=:username", nativeQuery = true)
	Employee getEmployee(@Param("username") String username);

	@Transactional
	@Modifying
	@Query(value = "update employee set password=:password where username=:username", nativeQuery = true)
	void changePassword(@Param("username") String username, @Param("password") String password);
}
