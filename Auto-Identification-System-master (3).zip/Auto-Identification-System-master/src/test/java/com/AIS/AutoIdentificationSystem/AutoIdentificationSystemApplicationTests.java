package com.AIS.AutoIdentificationSystem;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.ui.ModelMap;

import com.AutoIdentificationSystem.Controller.AuthController;

@SpringBootTest
class AutoIdentificationSystemApplicationTests {
	
	@Autowired
	private AuthController authController;

	@Test
	public void controllerIsNotNull() {
		assertThat(authController).isNotNull();
	}
	
	@Test
	public void testHomeController() {
		String result  = authController.rolePage(null);
		assertEquals(result, "role");
	}
	
	@Test
	public void testAdminRole() {
		String result = authController.adminLoginGet(new ModelMap(), null);
		assertEquals("adminPage", result);
	}

//	@Test
//	void admloginLogOutTest() {
//	assertEquals("adminLogout", authController.adminLogOut(new ModelMap()));
//	}
//	
	@Test
	public void BankEmployeeRoleTest() {
		String result = authController.employeeLoginGet(new ModelMap(), null);
		assertEquals("bankEmployee", result);
	}
	
	@Test
	public void BankEmployeeSignUpTest() {
		String result = authController.employeeSignupGet(new ModelMap(), null);
		assertEquals("EmpSignup", result);
	}
	
//	@Test
//	public void AdminTest() {
//		String result = authController.Admin(new UsersBean(), new ModelMap());
//		assertEquals("adminPage", result);
//		assertNotEquals("AdminSuccess", result);
//	}
	

}
